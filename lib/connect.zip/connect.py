import sys
import os
from os import path
import ssl
import json
import boto3
import base64
import pg8000 as pg


def get_secret(secret_name,region_name):
    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
        secretString=json.loads(get_secret_value_response['SecretString'])
        return secretString
    except Exception as e:
        print("Unable to get access keys from secretsmanager --Exiting")
        print(e)

def close_conn(conn):
    try:
        conn.close()
    except Exception as e:
        print("Exception in close_conn() function")
        PrintException()

def cert_download(cert_file,s3_bucket,region_name):
    #download cert file from s3
    try:
        s3 = boto3.client('s3', region_name=region_name)
        ingest_key=cert_file
        s3.download_file(s3_bucket,ingest_key,cert_file)
        print("Cert file download Completed")
        return True
    except Exception as e:
        print("Cert file downloading Failed")
        print(str(e))
        return False

def get_cert(cert_file,s3_bucket,region_name):
    try:
        if path.isfile(cert_file):
            context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
            context.load_verify_locations(cert_file)
            return context
        else:
            flag=False
            flag=cert_download(cert_file,s3_bucket,region_name)
            print(flag)
            if flag:
                context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
                context.load_verify_locations(cert_file)
                print("Cert file details retrieved")
                return context
        print("Not able to open cert file")
    except Exception as error:
        print(error)

def get_pg_conn(db_user,db_host,db_port,db_name,db_pwd,cert_file,s3_bucket,region_name):
    #connect to the redshift table
    conn = None
    try:
        context=get_cert(cert_file,s3_bucket,region_name)
        conn = pg.connect(user=db_user, host=db_host, port=int(db_port), \
        database=db_name, password=db_pwd,ssl_context=context)
        print("Connected to the redshift table")
    except Exception as e:
        print("Exception on Connect to Cluster: %s" % e)
        if conn is not None:
            close_conn(conn)
            return None

    conn.autocommit = True
    return conn

def pg_connect(db_user,db_host,db_port,db_name,db_pwd,query,cert_file,s3_bucket,region_name):
    #Read the records from redshift
    conn=get_pg_conn(db_user,db_host,db_port,db_name,db_pwd,cert_file,s3_bucket,region_name)
    try:
        cursor = conn.cursor()
        print(query)
        cursor.execute(query)
        print('Query executed in redshift table')
        query_result=cursor.fetchall()
        return query_result,conn
        conn.close
    except Exception as e:
        print("Exception in close_conn() function")
        print(e)

def pg_insert(db_user,db_host,db_port,db_name,db_pwd,query,cert_file,s3_bucket,region_name):
    #inserting records into redshift table
    conn=get_pg_conn(db_user,db_host,db_port,db_name,db_pwd,cert_file,s3_bucket,region_name)
    try:
        cursor=conn.cursor()
        print(query)
        cursor.execute(query)
        print("Inserted query into the redshift table")
        conn.commit
        conn.close
    except Exception as e:
        print("Exception in close_conn() function")
        print(e)

def get_vw(glueContext,view_name,jdbc_driver_name,db_url,db_username,db_password):
    try:
        df = glueContext.read.format("jdbc").option("driver", jdbc_driver_name)\
        .option("url", db_url) \
        .option("dbtable", view_name)\
        .option("user", db_username) \
        .option("password", db_password)\
        .load()
        print("Connection Success")
        return df
    except Exception as e:
        print("Connection Failed")
        print(e)


def s3_download(download_file,s3_bucket,region_name,obj):
    #download config file from s3
    try:
        s3 = boto3.client('s3', region_name=region_name)
        ingest_key=obj+download_file
        s3.download_file(s3_bucket,ingest_key,download_file)
        print("Config Download Completed")
        return True
    except Exception as e:
        print("Config Downloading Failed")
        print(str(e))
        return False


def get_config(download_file,s3_bucket,region_name,object):
    #read the config_file
    try:
        flag=False
        flag=s3_download(download_file,s3_bucket,region_name,object)
        if flag:
            #Read the credentials from the config file
            with open(download_file,"r") as config_file:
                jsonprop = json.load(config_file)
            return jsonprop

    except Exception as e:
        print("unable to read config file")
        print(str(e))
